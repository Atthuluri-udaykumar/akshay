import App from './App';

test('pass', () => {
  expect(App).toBeTruthy();
});
