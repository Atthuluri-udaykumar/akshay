import React from "react";
import PropTypes from "prop-types";
import {
    Button,
    DialogTitle,
    Dialog,
    Radio,
    RadioGroup,
    FormControlLabel,
    FormControl,
    DialogContent,
    DialogActions,
    Typography,
} from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { noop } from "lodash";

export interface IPublishActiveDialogProps {
    onClose: () => void;
    onContinue: () => void;
    open: boolean;
}

const useStyles = makeStyles((theme) => {
    return {
        dot: {
            display: "inline-block",
            fontWeight: "bold",
            margin: "0px 8px",
        },
    };
});

const InActiveDialog: React.FC<IPublishActiveDialogProps> = (
    props
) => {
    const { onClose, open } = props;

    return (
        <Dialog
            onClose={noop}
            open={open}
        >
            <DialogContent >
                <Typography>
                    This field cannot be inactive. You can either delete the question or create a new one.
                </Typography>
            </DialogContent>
            <DialogActions>
                <Button onClick={onClose} color="primary">
                    Ok
                </Button>
            </DialogActions>
        </Dialog >
    );
};

export default InActiveDialog;
