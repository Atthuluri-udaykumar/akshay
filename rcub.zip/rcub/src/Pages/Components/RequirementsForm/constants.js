export const NONE = "none";
export const END = "end"