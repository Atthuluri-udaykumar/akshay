import { Box, Button, Grid, Paper } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ReferenceDataAPI from "../../../api/referenceData";
import SearchAPI, { ISearchFormResultItem, ISearchFormsValue } from "../../../api/search";
import UserAttributesAPI from "../../../api/userAttributes";
import { IOption } from "../../../global/types";
import ButtonInput from "../../ReusableComponents/form/ButtonInput";
import { LinearLoader } from "../../ReusableComponents/form/LoadingComponent";
import MultiSelectDropdown from "../../ReusableComponents/form/MultiSelectDropdown";
import SingleSelectDropdown from "../../ReusableComponents/form/SingleSelectDropdown";
import LoadStateAndError from "../../ReusableComponents/LoadStateAndError";
import { getActiveReferenceData, getUniqueRecordsUsingName } from "../../ReusableComponents/ReferenceDataComponent/utils";
import DataGridTable from "../../ReusableComponents/table/DataGridTable";
import { ICountry } from "../ReferenceData/types";
import { ReferenceDataConverter } from "../ReferenceData/utils";
import { defaultSelectedOptions, IAnswerTableSearchControlsOptions } from "../RequirementsForm/types";

export interface IUnansweredCountryFormProps {
    isAdmin: boolean;
}
export interface IUnansweredForm extends ISearchFormResultItem {
    country: ICountry;
    status: string;
    countryName: string;
    id: string;
}

export interface ISearchOptions {
    dossierList: Array<IOption>;
    productTypeList: Array<IOption>;
    submissionTypeList: any;
    countries: Array<IOption>;
    regions?: Array<IOption>
  }

  const defaultSearchOptions:ISearchOptions = {
    dossierList:[],
    productTypeList:[],
    submissionTypeList: null,
    countries:[],
    regions:[]
  }



const UnansweredForm = (props: IUnansweredCountryFormProps)=>{
    const {isAdmin} = props;
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(5);
    const [options, setOptions] = useState<IAnswerTableSearchControlsOptions>(defaultSelectedOptions);
    const [selectedOptions, setSelectedOptions] = useState<ISearchOptions>(defaultSearchOptions);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<any>(null);    
    const [unansweredFormList, setUnansweredFormList] = useState<Array<any>>([]);
    const [linearLoader, setLinearLoader] = useState(false);
    const [tableShow, setTableShow] = useState(false);
    const navigate = useNavigate();
    // Load meta
    const getData = React.useCallback(async () => {
        try {
        setLoading(true);
        const [
            dossierList,
            productTypeList,
            submissionTypeList,
            regions,
            countries,
        ] = await Promise.all([
            ReferenceDataAPI.getDossierNodes(),
            ReferenceDataAPI.getRefferenceData(
            ReferenceDataAPI.paths.productType.read,
            ReferenceDataConverter.fields.productType.id,
            ReferenceDataConverter.fields.productType.name
            ),
            ReferenceDataAPI.getRefferenceData(
            ReferenceDataAPI.paths.submissionType.read,
            ReferenceDataConverter.fields.submissionType.id,
            ReferenceDataConverter.fields.submissionType.name
            ),
            ReferenceDataAPI.getRegions(),
            isAdmin ? ReferenceDataAPI.getActiveCountries() as Promise<IOption[]> : UserAttributesAPI.getUserCountriesList() as Promise<IOption[]>
        ]);
        setOptions({
            ...options,
            dossierList: getActiveReferenceData(dossierList),
            productTypeList: getActiveReferenceData(productTypeList),
            submissionTypeList: getActiveReferenceData(submissionTypeList),
            regions: [],//getUniqueRecordsUsingName(regions,'optionId','optionText'),
            countries,
        });
        } catch (err: any) {
        console.log(err);
        setError(err);
        }

        setLoading(false);
    }, []);

    useEffect(() => {
        getData();
    }, [getData]);

    /**
     *  Value is the value selected from the dropdown
     */
    const setFormOptions = async (value, inputType) => {
        setSelectedOptions({
        ...selectedOptions,
        [inputType]: value,
        });
    };

    const search = async() => {
       console.log(options);
       setLinearLoader(true);
       setTableShow(false);
       setPage(1);
       let submissionTypeId = selectedOptions.submissionTypeList?.optionId;
       let formName = selectedOptions.submissionTypeList.optionText;
       let countryIds = [];
       let productTypeIds = selectedOptions.productTypeList.map(key=> key.optionId );
       let dossierTypeIds = selectedOptions.dossierList.map(key=> key.optionId);

       let formOptions:ISearchFormsValue = {
        submissionTypeId: submissionTypeId,
        formName: formName,
        countryIds: countryIds,
        productTypeIds: productTypeIds,
        dossierTypeIds: dossierTypeIds
       }
        console.log(formOptions);
        const formData:any[] = await SearchAPI.searchFormUnfinished(formOptions);
        console.log(formData);
        let countries = selectedOptions.countries.length ? selectedOptions.countries :  options.countries;
        let unansweredFormList:Array<any> = [];
        formData.forEach(async(form) => {
            countries.forEach(async(country) => {
                /* eliminate finalized country from countries_list for each form */
                let toggle = form.finalized.some(ctry=> ctry.countries_id === country.optionId);
                if(toggle) return;
                /* end */
                const unansweredForm: IUnansweredForm = {
                    country,
                    countryName: country.optionText,
                    status: form.drafts.some(ctry=> ctry.countries_id === country.optionId) ? "drafts" : "unanswered",
                    ...form,
                    id: `${form.formId}-${country.optionId}`,
                    unique_id: `${form.formId}-${country.optionId}`
                  };
                  unansweredFormList.push(unansweredForm);
            })
        })
        setUnansweredFormList(unansweredFormList);
        setLinearLoader(false);
        setTableShow(true);
        console.log(unansweredFormList);
      };
      const onRowClick = async(item)=>{
        console.log(item);
        console.log()
        navigate(
            `/answerforms/${item.row.formId}?countryId=${item.row.country.optionId}&countryName=${item.row.country.optionText}`
          );
      }

      const columns = [
        //{ field: "formId", headerName: "Form ID" },
        { field: "formName", headerName: "Form Name", flex:1 },
        { field: "countryName", headerName: "Country Name", flex:1 },
        { field: "status", headerName: "status" },
      ];

    if (loading || error) {
        return (
          <div>
            <LoadStateAndError
              loading={loading}
              loadingMessage="Loading options..."
              error={error?.message}
            />
          </div>
        );
      }

    return (
        <>
            <Paper
                elevation={0}
                variant="outlined"
                sx={{margin:2}}
            >
                <Grid container spacing={1} sx={{ flexDirection:{xs:"column", md:"row"} }}
                    justifyContent="flex-start"
                >
                    <Grid item xs>
                        <SingleSelectDropdown
                            options={options.submissionTypeList}
                            label="Submission Type"
                            value={selectedOptions?.submissionTypeList}
                            getOptionLabel={(option) => option.optionText}
                            isOptionEqualToValue={(option, value) => option.optionId === value.optionId}
                            onChange={(value) => setFormOptions(value, "submissionTypeList")}
                        />
                    </Grid>
                    <Grid item xs>
                        <MultiSelectDropdown
                            label="Product type"
                            options={options.productTypeList}
                            value={selectedOptions?.productTypeList}
                            getOptionLabel={(option: IOption) => option.optionText}
                            isOptionEqualToValue={(option, value) =>
                                option.optionId === value.optionId
                            } //this function we use to suppress the warning generated by material
                            //limitTags={1}
                            onChange={(value) => setFormOptions(value, "productTypeList")}
                            limitTags={1}
                            />
                    </Grid>
                    <Grid item xs>
                        <MultiSelectDropdown
                            label="Dossier section"
                            options={options.dossierList}
                            value={selectedOptions?.dossierList}
                            getOptionLabel={(option: IOption) => option.optionText}
                            isOptionEqualToValue={(option, value) =>
                            option.optionId === value.optionId
                            } //this function we use to suppress the warning generated by material
                            onChange={(value) => setFormOptions(value, "dossierList")}
                            limitTags={1}
                        />
                    </Grid>
                    {isAdmin && <Grid item xs>
                        <MultiSelectDropdown
                            label="Regions"
                            options={options.regions!}
                            value={selectedOptions?.regions}
                            getOptionLabel={(option: IOption) => option.optionText}
                            isOptionEqualToValue={(option, value) =>
                            option.optionId === value.optionId
                            } //this function we use to suppress the warning generated by material
                            onChange={(value) => setFormOptions(value, "regions")}
                            disabled={true}
                            limitTags={1}
                        />
                    </Grid>}
                    <Grid item xs>
                        <MultiSelectDropdown
                            label="Countries"
                            options={options.countries}
                            value={selectedOptions?.countries}
                            getOptionLabel={(option: IOption) => option.optionText}
                            isOptionEqualToValue={(option, value) =>
                            option.optionId === value.optionId
                            } //this function we use to suppress the warning generated by material
                            onChange={(value) => setFormOptions(value, "countries")}
                            limitTags={1}
                        />
                    </Grid>
                </Grid>
                <Grid container>
                    <Grid item xs>
                    <ButtonInput
                        variant="contained"
                        color="primary"
                        disabled={!selectedOptions.submissionTypeList ? true : false}
                        loading={linearLoader}
                        text='Search'
                        onClick={search}
                    />
                    </Grid>
                </Grid>
                {linearLoader ? (
                    <Box sx={{ width: "100%" }}>
                    <LinearLoader variant="indeterminate" />
                    </Box>
                ) : (
                    " "
                )}            

                {
                    tableShow && 
                    <Grid container>
                    <Grid item xs>
                        <DataGridTable
                            loading={loading}
                            rows={unansweredFormList}
                            columns={columns}
                            page={page-1}
                            onPageSizeChange={(newPage) => setPageSize(newPage)}
                            rowsPerPageOptions={[5, 10, 20, 50, 100]}
                            pageSize={pageSize}
                            onPageChange={(newPage) => setPage(newPage+1)}
                            getRowId={(row) => row.unique_id}
                            getRowHeight={()=> 50}
                            onRowClick={onRowClick}
                            paginationMode={'client'}
                            disableSelectionOnClick={true}
                        />
                    </Grid>
                </Grid>
                }
            </Paper>
        
        </>
    )

};

export default UnansweredForm;