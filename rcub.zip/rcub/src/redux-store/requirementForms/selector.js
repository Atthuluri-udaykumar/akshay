import { getContainerSelectors } from "../utils";

const RequirementFormSelectors = getContainerSelectors("forms");

export default RequirementFormSelectors;
